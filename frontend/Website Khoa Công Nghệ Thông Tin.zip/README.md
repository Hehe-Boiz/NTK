
  # Website Khoa Công Nghệ Thông Tin

  This is a code bundle for Website Khoa Công Nghệ Thông Tin. The original project is available at https://www.figma.com/design/es7A3ShogJBqS08trkKO0C/Website-Khoa-C%C3%B4ng-Ngh%E1%BB%87-Th%C3%B4ng-Tin.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  